<?php get_header(); ?>

    <main>
        <section class="hero">
            <div class="hero-content">
                <h1>地域密着型の<br>歯科クリニック</h1>
            </div>
        </section>

<section class="section-padding">
    <div class="container two-column">
        <div class="column-text">
            <h2>クリニックの特徴</h2>
            <p>...</p>
            <a href="<?php echo home_url('/features'); ?>" class="btn">詳しくはこちら</a>
        </div>
    </div>
</section>  
                <div class="column-image">
                    <img src="<?php echo get_template_directory_uri(); ?>/images/family.png" alt="待合室で待つ家族">
                </div>
        </section>
        
        <section id="greeting" class="section-padding">
            <div class="container">
                <h2 class="text-center">院長の挨拶</h2>
                <p>
                    院長のコロナの影響により経営が傾いてしまった時、地域の方々の温かいお言葉や募金のお陰でやり続ける事が出来ました。<br>
                    コロナは空気感染と接触感染という感染方法があり、帰宅時に手洗いとうがいをするだけで感染のリスクを下げることができます。<br>
                    口を清潔に保つにはうがいだけでなく、歯を磨くということで感染率を下げて地域の皆様に健康でい続けてほしい。<br>
                    そんな気持ちで地域に寄り添い続けていきたいと思っています。
                </p>
            </div>
        </section>

<section class="section-padding">
    <div class="container two-column reverse">
        <div class="column-text">
            <h2>診療案内</h2>
            <p>...</p>
            <a href="<?php echo home_url('/information'); ?>" class="btn">詳しくはこちら</a>
        </div>
        </div>
</section>
                </div>
                <div class="column-image">
                    <img src="<?php echo get_template_directory_uri(); ?>/images/mokei.png" alt="歯の模型">
                </div>
            </div>
        </section>

        <section id="contact" class="section-padding bg-light-gray">
            <div class="container text-center">
                <h2>予約・お問い合わせ</h2>
                <div class="timetable">
                    <table>
                        <thead>
                            <tr>
                                <th>診療時間</th>
                                <th>9:00-12:30</th>
                                <th>14:30-18:00</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>月・火・木・金</td>
                                <td>●</td>
                                <td>●</td>
                            </tr>
                            <tr>
                                <td>水</td>
                                <td>-</td>
                                <td>-</td>
                            </tr>
                            <tr>
                                <td>土</td>
                                <td>●</td>
                                <td>-</td>
                            </tr>
                            <tr>
                                <td>日・祝</td>
                                <td>-</td>
                                <td>-</td>
                            </tr>
                        </tbody>
                    </table>
                    <p class="timetable-note">祝日·臨時休診のある週の水曜は診察いたします。<br>
                        ※受付は診療終了時間の30分前までとなります。</p>
                </div>
            </div>
        </section>

        <section id="access" class="access section-padding">
            <div class="container two-column">
                <div class="access-info">
                    <h2>アクセス情報</h2>
                    <p>〒000-0000 東京都〇〇区〇〇 1-2-3 〇〇ビル1F</p>
                    <p class="tel">TEL: 000-000-0000</p>
                    <p>ご予約の時間に遅れてしまう場合や道に迷ってしまった場合は電話でお知らせください。</p>
                </div>
                <div class="access-map">
                    <iframe 
                        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d25700.83856839958!2d136.5701888258381!3d36.50534274936081!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x5ff84f5f1489e2b1%3A0x334f5e714b6279f3!2z55-z5bed5biC5b255omA!5e0!3m2!1sja!2sjp!4v1722576001099!5m2!1sja!2sjp"
                        style="border:0;" 
                        allowfullscreen="" 
                        loading="lazy" 
                        referrerpolicy="no-referrer-when-downgrade">
                    </iframe>
                </div>
            </div>
        </section>
    </main>

<?php get_footer(); ?>