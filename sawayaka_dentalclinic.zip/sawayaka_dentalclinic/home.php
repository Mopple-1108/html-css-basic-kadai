<!-- header.php ここから -->
<!DOCTYPE html>
<html lang="ja">
<head>
  <meta charset="UTF-8">
  <meta name="description" content="さわやか歯科クリニックは、地域の声に寄り添いシニアの方も来訪しやすいようにバリアフリーを取り入れています。月１で訪問診療を実施し、地域の人に親しまれています。">
  <title>SAWAYAKA DANTAL CLINIC</title>
<link rel="stylesheet" href="style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+JP:wght@400;500;700&display=swap" rel="stylesheet">
</head>
<body>
  <!-- ヘッダー -->
  <header>
    <!-- ロゴ -->

     <div class="header-inner">
    <a href="index.html" id="logo">
      <img src="images/logo.png" alt="トップページに戻る">
    </a>

    <div class="header-tel">
        <p>TEL:XXX-XXX-XXXX</p>
        <a href="index.html#contact">予約・お問い合わせ</a>
    </div>

    </div>

     <nav id="nav-pc">
          <ul>
           <li><a href="features.html">当院の特徴</a></li>
           <li><a href="index.html#greeting">院長の挨拶</a></li>
           <li><a href="information.html">診療案内</a></li>
           <li><a href="index.html#access">アクセス</a></li>
          </ul>
     </nav>
    </header>
      <a href="index.html">
                  <img src="images/logo_big.png" />
                  <span>SAWAYAKA DANTAL CLINIC</span>
<main>
        <section class="hero">
            <div class="hero-content">
                <h1>地域密着型の<br>歯科クリニック</h1>
            </div>
        </section>

        <section class="section-padding">
            <div class="container two-column">
                <div class="column-text">
                    <h2>クリニックの特徴</h2>
                    <p>地域の声に寄り添いシニアの方も来訪しやすいようにバリアフリーを取り入れています。月１で訪問診療を実施し、地域の人に親しまれています。</p>
                    <a href="#" class="btn">詳しくはこちら</a>
                </div>
                <div class="column-image">
                    <img src="https://placehold.co/400x260/jpeg?text=家族の写真" alt="待合室で待つ家族">
                </div>
            </div>
        </section>

        <section id="greeting" class="section-padding bg-light-blue">
            <div class="container text-center">
                <h2>院長の挨拶</h2>
                <p>
                    院長のコロナの影響により経営が傾いてしまった時、地域の方々の温かいお言葉や募金のお陰でやり続ける事が出来ました。<br>
                    コロナは空気感染と接触感染という感染方法があり、帰宅時に手洗いとうがいをするだけで感染のリスクを下げることができます。<br>
                    口を清潔に保つにはうがいだけでなく、歯を磨くということで感染率を下げて地域の皆様に健康でい続けてほしい。<br>
                    そんな気持ちで地域に寄り添い続けていきたいと思っています。
                </p>
            </div>
        </section>

        <section class="section-padding">
            <div class="container two-column reverse">
                <div class="column-text">
                    <h2>診療案内</h2>
                    <p>虫歯や歯周病治療、これ等の予防、口腔外からの治療、ブラッシング指導、フッ素塗布などを中心とした予防治療、ホワイトニング等が主な診察内容となっています。</p>
                    <a href="#" class="btn">詳しくはこちら</a>
                </div>
                <div class="column-image">
                    <img src="https://placehold.co/400x260/jpeg?text=歯の模型" alt="歯の模型">
                </div>
            </div>
        </section>

        <section id="contact" class="section-padding bg-light-gray">
            <div class="container text-center">
                <h2>予約・お問い合わせ</h2>
                <p>ご予約の時間に遅れてしまう場合や道に迷ってしまった場合は電話でお知らせください。</p>
                <div class="timetable">
                    <table>
                        <thead>
                            <tr>
                                <th>診療時間</th>
                                <th>9:00-12:30</th>
                                <th>14:30-18:00</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>月・火・木・金</td>
                                <td>●</td>
                                <td>●</td>
                            </tr>
                            <tr>
                                <td>水</td>
                                <td>●</td>
                                <td>-</td>
                            </tr>
                            <tr>
                                <td>土</td>
                                <td>●</td>
                                <td>▲</td>
                            </tr>
                            <tr>
                                <td>日・祝</td>
                                <td>-</td>
                                <td>-</td>
                            </tr>
                        </tbody>
                    </table>
                    <p class="timetable-note">▲...14:30-17:00</p>
                </div>
            </div>
        </section>

        <section id="access" class="access section-padding">
            <div class="container two-column">
                <div class="access-info">
                    <h2>アクセス情報</h2>
                    <img src="https://placehold.co/150x40/png?text=LOGO" alt="クリニックのロゴ" class="access-logo">
                    <p>〒000-0000 東京都〇〇区〇〇 1-2-3 〇〇ビル1F</p>
                    <p class="tel">TEL: 000-000-0000</p>
                    <p>ご予約の時間に遅れてしまう場合や道に迷ってしまった場合は電話でお知らせください。</p>
                </div>
                <div class="access-map">
                 <iframe 
                   src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d25700.83856839958!2d136.5701888258381!3d36.50534274936081!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x5ff84f5f1489e2b1%3A0x334f5e714b6279f3!2z55-z5bed5biC5b255omA!5e0!3m2!1sja!2sjp!4v1722576001099!5m2!1sja!2sjp" 
                   style="border:0;" 
                   allowfullscreen="" 
                   loading="lazy" 
                   referrerpolicy="no-referrer-when-downgrade">
                 </iframe>
                </div>
            </div>
        </section>
    </main>

    <footer class="footer">
        <div class="footer-nav">
            <a href="#">HOME</a>
            <a href="#">当院の特徴</a>
            <a href="#">院長の挨拶</a>
            <a href="#">診療案内</a>
            <a href="#">アクセス情報</a>
        </div>
        <p class="copyright">&copy; 2025 SAWAYAKA DENTAL CLINIC</p>
    </footer>

</body>
</html>
