<footer class="footer">
        <img src="<?php echo get_template_directory_uri(); ?>/images/futterlogo.png">
        <div class="footer-nav">
          <a href="<?php echo home_url('/'); ?>">TOP</a>
          <a href="<?php echo home_url('/features'); ?>">当院の特徴</a>
          <a href="<?php echo home_url('/#greeting'); ?>">院長の挨拶</a>
          <a href="<?php echo home_url('/information'); ?>">診療案内</a>
          <a href="<?php echo home_url('/#access'); ?>">アクセス情報</a>
        </div>
        <p class="copyright">© 2025 SAWAYAKA DENTAL CLINIC</p>
    </footer>

    <?php wp_footer(); // WordPressのJSなどを自動で出力する必須タグ ?>
</body>
</html>