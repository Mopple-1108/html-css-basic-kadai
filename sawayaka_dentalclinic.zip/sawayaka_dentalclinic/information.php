<?php
/*
Template Name: 診療内容
*/
get_header(); ?>

    <main>
        <div class="page-title">
            <h1 class="text-center">診療内容</h1>
        </div>

        <section class="features-content section-padding">
            <div class="container">
                <p>小児歯科（フッ素塗布、シーラント）、虫歯・歯周病治療、口腔外からの治療、ブラッシング指導、入れ歯（義歯）、インプラント、審美歯科などを中心とした予防治療、ホワイトニング等が主な診察内容となっています。</p>
                <p>幅広いニーズに対応でき、おじいちゃんやおばあちゃんの入れ歯の相談と、お子さんのフッ素塗布を一緒にやることで少しでも安心して治療が受けられるようにスタッフ一同準備しております。</p>
                <p>より高度な治療（難しい親知らずの抜歯、矯正歯科、口腔外科など）が必要な場合に、地域の基幹病院や大学病院、専門医とスムーズに連携できる体制が整えているため安心してご相談ください。</p>
                <p>急を要する場合でも先ず当院にご連絡ください。</p>
                
                <div class="main-feature-img text-center">
                    <img src="<?php echo get_template_directory_uri(); ?>/images/mokei.png" alt="歯の模型の画像">
                </div>
            </div>
        </section>

        <?php get_template_part('template-parts/access-section'); ?> 
    </main>

<?php get_footer(); ?>