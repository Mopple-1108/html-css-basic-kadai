<section id="access" class="access section-padding">
    <div class="container two-column">
        <div class="access-info">
            <h2>アクセス情報</h2>
            <p>〒XXX-XXXX</p>
            <p>XX道XX市XX町X丁目X-XX</p>
            <p>XXX駅から車でX分 (約XXkm)</p>
            <p>XX駅前 バス停 徒歩X分</p>
            <p>駐車場 X台</p>
            <p class="tel">TEL. 000-000-0000</p>
            <p>ご予約の時間に遅れてしまう場合や道に迷ってしまった場合は電話でお知らせください。</p>
        </div>
        <div class="access-map">
            <iframe 
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d25700.83856839958!2d136.5701888258381!3d36.50534274936081!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x5ff84f5f1489e2b1%3A0x334f5e714b6279f3!2z55-z5bed5biC5b255omA!5e0!3m2!1sja!2sjp!4v1722576001099!5m2!1sja!2sjp"
                style="border:0;" 
                allowfullscreen="" 
                loading="lazy" 
                referrerpolicy="no-referrer-when-downgrade">
            </iframe>
        </div>
    </div>
</section>