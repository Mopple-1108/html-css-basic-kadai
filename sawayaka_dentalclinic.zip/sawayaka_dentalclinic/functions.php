<?php
// テーマのセットアップ
function my_theme_setup() {
    // スタイルシートを読み込む
    // get_stylesheet_uri() は style.css のURLを返す
    wp_enqueue_style( 'my-theme-style', get_stylesheet_uri() );

    // 必要であればGoogle Fontsもここで読み込む (直接header.phpに記述しても動作はしますが、こちらが推奨)
    // wp_enqueue_style( 'noto-sans-jp', 'https://fonts.googleapis.com/css2?family=Noto+Sans+JP:wght@400;500;700&display=swap', array(), null );
}
add_action( 'wp_enqueue_scripts', 'my_theme_setup' );

// ページタイトルを動的に変更
function my_theme_wp_title( $title, $sep ) {
    if ( is_feed() ) {
        return $title;
    }
    global $page, $paged;

    // Add the blog name
    $title .= get_bloginfo( 'name', 'display' );

    // Add the blog description for the home/front page.
    $site_description = get_bloginfo( 'description', 'display' );
    if ( $site_description && ( is_home() || is_front_page() ) ) {
        $title .= " $sep $site_description";
    }

    // Add a page number if necessary:
    if ( ( $paged >= 2 || $page >= 2 ) && ! is_archive() ) {
        $title .= " $sep " . sprintf( __( 'Page %s', 'mytheme' ), max( $paged, $page ) );
    }
    return $title;
}
add_filter( 'wp_title', 'my_theme_wp_title', 10, 2 );

// サムネイル画像の有効化 (もし投稿で画像を使いたい場合)
// add_theme_support('post-thumbnails');

// ナビゲーションメニューの有効化 (もしWordPressのメニュー機能を使いたい場合)
// register_nav_menus( array(
//     'primary' => 'メインメニュー',
// ) );

?>