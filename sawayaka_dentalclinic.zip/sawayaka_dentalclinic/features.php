<?php
/*
Template Name: 当院の特徴
*/
get_header(); ?>

    <main>
        <div class="page-title">
            <h1 class="text-center">クリニックの特徴</h1>
        </div>

        <section class="features-content section-padding">
            <div class="container">
                <p>地域の声に寄り添うために意見箱を設置したり、地域に密着するだけでなくかかりつけ歯科医として、リモート診察の相談や質問も受け付けています。</p>
                <p>シニアの方も来訪しやすいようにバリアフリーを取り入れ負担がないように当院の造りから拘っています。</p>
                <p>その場限りの治療ではなく、お子様の成長、進学、就職、結婚、出産、そしてシニアライフまで、患者様のライフステージの変化に寄り添い、お口の健康を生涯にわたってサポートしていくために月１で訪問診療を支援し、地域の人に親しまれています。</p>
                
                <div class="main-feature-img text-center">
                    <img src="<?php echo get_template_directory_uri(); ?>/images/family.png" alt="家族の画像">
                </div>
            </div>
        </section>

        <?php get_template_part('template-parts/access-section'); ?> 
    </main>

<?php get_footer(); ?>