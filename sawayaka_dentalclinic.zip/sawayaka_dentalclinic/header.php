<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="<?php bloginfo('description'); ?>">
    <title><?php wp_title('|', true, 'right'); ?><?php bloginfo('name'); ?></title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+JP:wght@400;500;700&display=swap" rel="stylesheet">
    
    <?php wp_head(); // WordPressのCSSやJSなどを自動で出力する必須タグ ?>
</head>
<body <?php body_class(); ?>>
    
    <header class="header">
        <div class="header-top">
            <div class="container container-header">
              <a href="<?php echo home_url('/'); ?>" class="logo-header">
                <img src="<?php echo get_template_directory_uri(); ?>/images/logo.png" alt="SAWAYAKA DENTAL CLINIC アイコン">
                <img src="<?php echo get_template_directory_uri(); ?>/images/logo_big.png" alt="SAWAYAKA DENTAL CLINIC 文字ロゴ" class="text-logo">
              </a>
    <div class="header-contact">
        <span class="tel-header">TEL.XXX-XXX-XXXX</span>
        <a href="<?php echo home_url('/#contact'); ?>" class="btn-header">ご予約・お問い合わせ</a>
    </div>
</div>
        </div>
        <nav class="global-nav">
            <ul>
                <li><a href="<?php echo home_url('/'); ?>" <?php if (is_front_page()) echo 'class="current-page"'; ?>>トップ</a></li>
                <li><a href="<?php echo home_url('/features'); ?>" <?php if (is_page('features')) echo 'class="current-page"'; ?>>当院の特徴</a></li>
                <li><a href="<?php echo home_url('/#greeting'); ?>">院長の挨拶</a></li>
                <li><a href="<?php echo home_url('/information'); ?>">診療内容</a></li>
                <li><a href="<?php echo home_url('/#access'); ?>">アクセス</a></li>
            </ul>
        </nav>
    </header>

    <main>